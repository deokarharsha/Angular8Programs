import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {

  username:String="Saloni"
  age:number = 10

  constructor() { }

  ngOnInit() {
  }

  m1(){
    
    this.age += 10
  }

}
