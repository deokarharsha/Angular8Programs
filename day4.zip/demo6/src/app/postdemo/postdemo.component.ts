import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postdemo',
  templateUrl: './postdemo.component.html',
  styleUrls: ['./postdemo.component.css']
})
export class PostdemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
