import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getdemo',
  templateUrl: './getdemo.component.html',
  styleUrls: ['./getdemo.component.css']
})
export class GetdemoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
