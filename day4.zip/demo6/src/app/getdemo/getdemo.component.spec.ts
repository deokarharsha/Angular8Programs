import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetdemoComponent } from './getdemo.component';

describe('GetdemoComponent', () => {
  let component: GetdemoComponent;
  let fixture: ComponentFixture<GetdemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetdemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetdemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
