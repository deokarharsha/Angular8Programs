import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmpcompComponent } from './empcomp/empcomp.component';



@NgModule({
  declarations: [EmpcompComponent],
  imports: [
    CommonModule
  ]
})
export class EmpmodModule { }
