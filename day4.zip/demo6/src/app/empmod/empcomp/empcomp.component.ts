import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empcomp',
  templateUrl: './empcomp.component.html',
  styleUrls: ['./empcomp.component.css']
})
export class EmpcompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
