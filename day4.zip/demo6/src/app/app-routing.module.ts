import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GetdemoComponent } from './getdemo/getdemo.component';
import { StudentComponent } from './nesting/student/student.component';
import { PostdemoComponent } from './postdemo/postdemo.component';


const routes: Routes = [
  {path:"getpath", component:GetdemoComponent},
  {path:"postpath", component:PostdemoComponent},
  {path:"studpath", component:StudentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
