import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-grade',
  templateUrl: './grade.component.html',
  styleUrls: ['./grade.component.css']
})
export class GradeComponent implements OnInit, OnChanges {
  @Input()
  marks:number=10
  @Output()
  invalid:EventEmitter<String>= new EventEmitter() 
  grade:string="ClassLevelInitialization"
  constructor() {
    console.log("in constructor of Grade and current value of marks =" + this.marks )
   }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("ngOnChanges invoked ...")
    console.log(changes)
    this.findgrade()
    
  }

  ngOnInit() {
    console.log("in ngOnInit of Grade and current value of marks =" + this.marks )
    this.findgrade()
   
  }

  findgrade(){
    if (this.marks > 100){
        this.invalid.emit("Wrong Marks.....")
      }
    if (this.marks>=35)
      this.grade="Pass"
    else
      this.grade="Fail"
  }
}
