import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

  name:string="Seema"
  studmarks:number=40
  constructor() { }

  ngOnInit() {
  }

  handleinvalid(event){
    console.log("in studentComponetn - handleInvalid")
    console.log(event)
  }
}
