import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule  } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { GetdemoComponent } from './getdemo/getdemo.component';
import { PostdemoComponent } from './postdemo/postdemo.component';
import { NestingModule } from './nesting/nesting.module'

@NgModule({
  declarations: [
    AppComponent,
    GetdemoComponent,
    PostdemoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    NestingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
