import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyService {

  constructor(private httpclient : HttpClient) { }

  public postuser(name:string, job:string){
    console.log("in postuser of MyService " + name + ", "+job)
   return this.httpclient.post<any>('https://reqres.in/api/users', {​"name": name, "job": job}​)
  }
}


/*
    this.httpclient.post<any>('https://reqres.in/api/users', {​"name": this.name, "job": this.job}​).subscribe(
successdata=>{​
console.log("success ");
this.userdata = successdata;
}​,
errordata =>{​ console.log("error ");
console.log( errordata);
this.userdata = errordata;
}​
)
*/