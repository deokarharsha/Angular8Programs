import { Component, OnInit } from '@angular/core';
import { MyService } from '../my.service';

@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css']
})
export class Comp1Component implements OnInit {
  name:string ="myname"
  job:string="trainer"
  userdata={}
  constructor(private my:MyService) { }

  ngOnInit() {
  }

  sendpost(){
    this.my.postuser(this.name, this.job).subscribe(
      successdata=>{​
      console.log("success ");
      this.userdata = successdata;
      }​,
      errordata =>{​ console.log("error ");
      console.log( errordata);
      this.userdata = errordata;
      }​
      )
      
  }
}
