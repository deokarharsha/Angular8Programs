import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  url = "https://reqres.in/api/users?page="
  userarr:Array<Object>=[]
  constructor(private httpclient:HttpClient) { }

  ngOnInit() {
  }

  fetchdata(pagenumber:number){
 
    let observable1 = this.httpclient.get(this.url+pagenumber)
    observable1.subscribe(
      successdata=>{
        console.log("success "); 
 
        this.userarr = successdata['data']
        console.log(this.userarr)
    },
      errordata =>{ console.log("error ");
                  console.log( errordata);}

    )
  }
}
