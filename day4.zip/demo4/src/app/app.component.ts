import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  user={}
  url ="https://reqres.in/api/users/"
  constructor(private httpclient:HttpClient){

  }
  getInfo(){
    console.log("Getting Details from Server")
    console.log(this.httpclient)
    let observable1 = this.httpclient.get(this.url+"1")
    observable1.subscribe(
      successdata=>{
        console.log("success "); 
        console.log(successdata);
        this.user = successdata['data']
    },
      errordata =>{ console.log("error ");
                  console.log( errordata);}

    )
  }
}
