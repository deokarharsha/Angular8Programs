import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { Count1Component } from './count1/count1.component';
import { Count2Component } from './count2/count2.component';
import { Count3Component } from './count3/count3.component';

@NgModule({
  declarations: [
    AppComponent,
    Count1Component,
    Count2Component,
    Count3Component
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
