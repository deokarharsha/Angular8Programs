import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AddService {

  count:number=0
  constructor() { 
    console.log("AddService Constructor invoked ")
  }

  public add(){
    this.count++
  }

  public getCount(){
    return this.count
  }
}
