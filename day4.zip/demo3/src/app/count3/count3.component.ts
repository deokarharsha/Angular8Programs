import { Component, OnInit } from '@angular/core';
import { AddService } from '../add.service';

@Component({
  selector: 'app-count3',
  templateUrl: './count3.component.html',
  styleUrls: ['./count3.component.css']
})
export class Count3Component implements OnInit {

 
  ngOnInit() {
  }
  myservice:AddService
  constructor(service1:AddService) {
      this.myservice = service1
   }
   addcount(){
     this.myservice.add()
   }
}
