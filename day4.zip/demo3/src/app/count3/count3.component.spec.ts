import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Count3Component } from './count3.component';

describe('Count3Component', () => {
  let component: Count3Component;
  let fixture: ComponentFixture<Count3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Count3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Count3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
