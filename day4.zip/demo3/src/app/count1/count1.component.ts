import { Component, OnInit } from '@angular/core';
import { AddService } from '../add.service';

@Component({
  selector: 'app-count1',
  templateUrl: './count1.component.html',
  styleUrls: ['./count1.component.css'],
  
})
export class Count1Component implements OnInit {
 /*
  myservice:AddService
  constructor(service1:AddService) {
      this.myservice = service1
   }
  */
   constructor(private myservice:AddService) {
    
 }
   addcount(){
     this.myservice.add()
   }

  ngOnInit() {
  }

}
