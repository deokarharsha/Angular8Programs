import { Component, OnInit } from '@angular/core';
import { AddService } from '../add.service';

@Component({
  selector: 'app-count2',
  templateUrl: './count2.component.html',
  styleUrls: ['./count2.component.css'],
  providers:[AddService]
})
export class Count2Component implements OnInit {


  ngOnInit() {
  }
  myservice:AddService
  constructor(service1:AddService) {
      this.myservice = service1
   }
   addcount(){
     this.myservice.add()
   }
}
