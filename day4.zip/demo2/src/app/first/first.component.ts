import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent implements OnInit {
  empvar:Emp = new Emp()
  emparr:Array<Emp>=[]
  constructor() { }

  ngOnInit() {
  }

  addEmp(){
    this.emparr.push(this.empvar);
    this.empvar = new Emp()
    console.log(this.emparr)
  }
  delete(rownum){
    console.log("rownum to delete" + rownum)
    this.emparr.splice(rownum,1)
  }
}
