export class Emp {
    empno:number=1
    ename:String="aa"
    salary:number=11
}
